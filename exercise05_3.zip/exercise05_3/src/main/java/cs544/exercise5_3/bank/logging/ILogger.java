package cs544.exercise5_3.bank.logging;

public interface ILogger {
    public void log (String logstring);
}
